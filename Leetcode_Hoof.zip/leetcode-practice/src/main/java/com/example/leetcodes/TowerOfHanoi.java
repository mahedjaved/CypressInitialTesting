package com.example.leetcodes;

/**
 * Hello world!
 *
 */
public class TowerOfHanoi {
    public static void TowerMove(int n, char src, char aux, char dest) {
        if (n == 1) {
            System.out.println(src + " -> " + dest);
            return;
        }
        TowerMove(n - 1, src, dest, aux);
        TowerMove(1, src, aux, dest);
        TowerMove(n - 1, aux, src, dest);
    }

    public static void main(String[] args) {
        TowerMove(3, 'A', 'B', 'C');
    }
}
