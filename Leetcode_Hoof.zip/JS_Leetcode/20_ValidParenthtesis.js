// Valid Parenthesis is Leetcode 20

// using stack in this case is better and feasible and use push and pop
// STACK = LIST

let input_string = "())))))))";

const stack = [];

// compare elements of stack with these options
const parens = "() {} []";

// use variable to store index of the string
let i = 0;

while (i < input_string.length) {
  // add the element into the stack
  stack.push(input_string[i]);
  i++;

  // pull out last two elements in the stack for us to compare
  let open = stack[stack.length - 2];
  let closed = stack[stack.length - 1];

  // are the above valid open or close
  let potParens = open + closed;
  console.log(stack);
  console.log(potParens);

  if (parens.includes(potParens)) {
    // if they are valid, remove them from stack
    stack.pop();
    stack.pop();
  }

  console.log(stack.length === 0);
}
