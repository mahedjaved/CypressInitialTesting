// tutorial on intro to graphs :: https://www.youtube.com/watch?v=cWNEl4HE2OE

// *************************************** //
//           Setting Up The Graph
// *************************************** //
const airports = "PHX BKK OKC JFK LAX MEX EZE HEL LOS LAP LIM".split(" ");

const routes = [
  ["PHX", "LAX"],
  ["PHX", "JFK"],
  ["JFK", "OKC"],
  ["JFK", "HEL"],
  ["JFK", "LOS"],
  ["MEX", "LOS"],
  ["MEX", "BKK"],
  ["MEX", "LIM"],
  ["MEX", "EZE"],
  ["LIM", "BKK"],
];

// choice here : a) represent as adjacency matrix   b) represent as a list
// adjacency matrix takes more space , but easy to represent
// vice versa for list
// however "golden rule dictates" : if data is sparese (less combinations) the matrix rep. will have more zeroes, traversal will be a waste of time
// best use list in this case, this represented as a key-value pair, key is name of airport, value is array of edges (other ariports it is connected to)
const adjacencyList = new Map();

// define function to add node to add an empty list (psuedo airport) to the adj. list
const addNode = (airport) => {
  adjacencyList.set(airport, []);
};

// add an edge to the adj. list
const addEdge = (origin, destination) => {
  // get the origin (key) and push the destination  onto its value (the list)
  adjacencyList.get(origin).push(destination);
  // obv. do the inverse to complete the "undirected" requirements
  adjacencyList.get(destination).push(origin);
};

// use the application above to create the graph
airports.forEach(addNode);
routes.forEach((route) => addEdge(...route));

// *************************************** //
//           Graph Traversal
// *************************************** //

// bfs takes the starting node as an argument, it needs to also know that if a node has been visited or not, otherwise it will open the one adjacent to it.
// we represent this using a queue, which in JS is an array in which the first item in is the first item out
const bfs = (start) => {
  // keep a storage of visited nodes, (using a set, since all values will be unique)
  const visited = new Set();
  // the first item in the queue is the starting node
  const queue = [start];
  // while the queue is NOT empty
  // console.log(queue.length);
  while (queue.length > 0) {
    // grab the first item using shift (which wil remove it from the queue as well)
    const airport = queue.shift();
    // grab all the edges of this node
    const destinations = adjacencyList.get(airport);
    // loop over the edges, check if visited or not, if not then add to queue, otherwise move to another node
    for (const destination of destinations) {
      if (destination === "BKK") {
        console.log("Found the destination: " + destination);
      }

      if (!visited.has(destination)) {
        visited.add(destination);
        queue.push(destination);
        console.log(destination);
      }
    }
  }
};

// bfs("PHX");

// *************************************** //
//           Does a Route Exist - DFS Example
// *************************************** //

// if you want to find a link asap then using DFS is probs. much better option, dont open all children, you keep opening the child, then its child, and then backtrack (hence you use recursive)
let steps = 0;
const dfs = (start, visited = new Set()) => {
  console.log(start);
  visited.add(start);

  const destinations = adjacencyList.get(start);
  for (const destination of destinations) {
    if (destination === "BKK") {
      console.log(`DFS found Bangkok in ${steps} steps`);
      return;
    }
    if (!visited.has(destination)) {
      steps++;
      dfs(destination, visited);
    }
  }
};

dfs("PHX");
