class Solution {
  maxSumAfterPartitioning(arr, k) {
    const recursiveFunc = (i) => {
      // Base case
      if (i >= arr.length) {
        return 0;
      }

      let max = 0;
      let result = 0;

      for (let j = i; j < Math.min(arr.length, i + k); j++) {
        max = Math.max(max, arr[j]);
        let total_size = j - i + 1;
        result = Math.max(result, recursiveFunc(j + 1) + max * total_size);
      }
      return result;
    };
    return recursiveFunc(0);
  }
}

// Example -01
const solution = new Solution();
const arr = [1, 15, 7, 9, 2, 5, 10];
const k = 3;
const result = solution.maxSumAfterPartitioning(arr, k);
console.log(result); 
