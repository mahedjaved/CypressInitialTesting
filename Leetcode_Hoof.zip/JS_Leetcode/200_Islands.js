const grid = [
  ["1", "1", "1", "1", "0"],
  ["1", "1", "0", "1", "0"],
  ["1", "1", "0", "0", "0"],
  ["0", "0", "0", "0", "0"],
];

const transformedGrid = grid.map((row) => row.map((cell) => false));

const getAdjacentNeighbours = (i, j, grid, visited) => {
  // array to hold them
  const adjacentNeighbours = [];
  // get four neighbours, top/bottom/left/right
  if (i > 0 && !visited[i - 1][j]) {
  }
  return adjacentNeighbours;
};
const DFS = (i, j, grid, visited) => {
  // using a STACK for DFS, and queue for BFS
  const stack = [[i, j]];
  let islandSize = 0;

  // while stack has something in it
  while (stack.length) {
    // pop of the current node
    let curNode = stack.pop();
    // destructure i and j in the current node
    let [i, j] = curNode;
    // is this cell has been visited at i and j
    if (visited[i][j]) {
      continue;
    }
    // otherwise now visit it and set this place as visited
    visited[i][j] = true;
    // check if cell is part of an island ['0' means NOT an island], ['1' is Water]
    if (grid[i][j] === "0") continue;
    islandSize++;
    // if we hit water, then we need to check a cell above, left, right and below (all adjacent to the cell)
    let adjNeighbours = getAdjNeighbous(i, j, grid, visited);

    // push adjacent neighbours into the stack
    stack.push(...adjNeighbours);
  }

  return islandSize > 0 ? true : false;
};

let islandCount = 0;

// loop through the row
for (let i = 0; i < grid.length; i++) {
  // each entries within
  for (let j = 0; i < grid[i].length; j++) {
    // check if DFS is returning True or False
    if (DFS(i, j, grid, visited)) {
      // means we found ISLAND in that node
      islandCount++;
    }
  }
}

// how to print from an array
console.log("Transformed Grid:");
transformedGrid.forEach((row) => {
  console.log(row.join(" "));
});
