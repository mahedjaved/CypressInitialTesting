// https://www.youtube.com/watch?v=oIzYd97dtq8&list=PLrClazTqVpJlyey7Szwe_XX9meD4wl2Ma&index=3
// you need to represent the cities as an adjacency list
// and then run a graph based algorithm, you can use DFS or BFS,   DFS uses queue and is cleaner

// set it as object
const visited = {};

// build the adjacency matrix
const adjList = buildAdjList(isConnected);

// set provinces
let provinces = 0;

// traverse the graph
for (let vertex = 0; vertex < adjList.length; vertex++) {}
